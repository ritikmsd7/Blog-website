import React,{useState} from 'react'
import './App.css'
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home'
import Blog from './pages/Blog'
import Category from './pages/Category'
import Tag from './pages/Tag'
const App = () => {
  const [flag,setflag]=useState(false);
  return (


   <div>
    {
      flag?( <div className='bg-black text-white'>
     
     <Routes>
      <Route path='/' element=<Home flag={flag} setflag={setflag}></Home>></Route>
      <Route path='/blog/:blogID' element=<Blog flag={flag} setflag={setflag}></Blog>></Route>
      <Route path='/categories/:category' element=<Category flag={flag} setflag={setflag}></Category>></Route>
      <Route path='/tags/:tagname' element=<Tag flag={flag} setflag={setflag}></Tag>></Route>
     </Routes>

    </div>):( 
       
     <div>
     <Routes>
      <Route path='/' element=<Home flag={flag} setflag={setflag}></Home>></Route>
      <Route path='/blog/:blogID' element=<Blog flag={flag} setflag={setflag}></Blog>></Route>
      <Route path='/categories/:category' element=<Category flag={flag} setflag={setflag}></Category>></Route>
      <Route path='/tags/:tagname' element=<Tag flag={flag} setflag={setflag}></Tag>></Route>
     </Routes>
     </div>
     

   )
    }
   </div>
  )
}

export default App;

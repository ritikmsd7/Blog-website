import {React,useEffect,useState} from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../component/Header'
import Spinner from '../component/Spinner'
import Main from '../component/Main'

const Blog = ({flag,setflag}) => {
   const navigation=useNavigate();
   const location=useLocation();
   
    const [blog,setblog]=useState("");
    const [loading,setloading]=useState(false);
   const [related,setrelatedblog]=useState("");
    const [blogid,setblogid]=useState("");
    const url=`https://codehelp-apis.vercel.app/api/get-blog?blogId=${blogid}`;

    async function fetchurl(){
        setloading(true);
        try{
        const res=await fetch(url);
        const data=await res.json();
       
        setblog(data.blog);
        setrelatedblog(data.relatedBlogs)

       
        }
        catch(e){
            console.log("error found")
        }
        setloading(false);
    }

    useEffect(()=>{
        fetchurl();
        setblogid(location.pathname.split("/").at(-1));
    },[blogid]);
     
    
    console.log(blog);
   
  return (
    <div  >
        <Header flag={flag} setflag={setflag}></Header>

      <div className='mt-[100px] flex gap-x-2 mx-[425px] items-center'>
          <button className='border-2 py-1 px-4 rounded-md'onClick={()=>navigation(-1)}>Back</button>    
      </div>
        
        <div className='mt-[30px] flex flex-col items-center justify-center'>
        <div className='w-11/12 max-w-[670px]  gap-y-10  mb-[60px]'>

          <div className='font-bold text-lg hover:underline'>

          {blog.title}

          </div>
          <div className='my-1 text-sm'>
            By{" "}
            <span className='italic'>{blog.author} </span>
            On{" "}
            
            <span className=' font-bold underline'>{blog.category}</span>


          </div>

          <div className='my-1 text-sm'>Posted On {blog.date}</div>

          <p className='mt-4 mb-2'>{blog.content}</p>
          <div className='flex gap-x-2'>
          {
              blog.tags?(blog.tags.map((tag,index)=>(
                  <div key={index} >
                      <span className=' text-xs font-semibold underline text-blue-700 cursor-pointer'>
                    
                      {`#${tag}`}
                      
                    
                      </span>
                  </div>
              ))):(<div>nothing found</div>)
          }
          </div>

          </div>

        </div>
     
        
        <h2 className='mx-[425px] text-3xl font-bold'>Related Blogs</h2>
       <div className='mt-[38px] flex flex-col items-center justify-center'>
       <div className='w-11/12 max-w-[670px] flex flex-col gap-y-7  items-center mb-[70px]'>
        {
           
           loading?(<Spinner></Spinner>):(
               
               related?(related.map((post,index)=>(
                  
                   <Main post={post} key={index} ></Main>
                   
               ))):(<div>No data found</div>)
           )
        
          
      }
      </div>
       </div>
       
      
       
       
    </div>
  )
 
}

export default Blog;
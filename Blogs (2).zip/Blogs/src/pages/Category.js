import {React,useEffect,useState} from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../component/Header'
import Spinner from '../component/Spinner'
import Main from '../component/Main'
import Pagination from '../component/Pagination'
const Category = ({flag,setflag}) => {
   const navigation=useNavigate();
   const location=useLocation();
    const [totalpage,settotalpage]=useState(1);
    const [output,setoutput]=useState("");
    const [loading,setloading]=useState(false);
    const [page,setpage]=useState(1);
    const [category,setcategory]=useState("");
    const url=`https://codehelp-apis.vercel.app/api/get-blogs?page=${page}&category=${category}`;

    async function fetchurl(){
        setloading(true);
        try{
        const res=await fetch(url);
        const data=await res.json();
        setoutput(data.posts);
        settotalpage(data.totalPages);
       
        }
        catch(e){
            console.log("error found")
        }
        setloading(false);
    }

    useEffect(()=>{
        fetchurl();
        setcategory(location.pathname.split("/").at(-1).replaceAll("-"," "));
    },[page,category]);
     
    console.log(category);
   
  return (
    <div  >
        <Header flag={flag} setflag={setflag}></Header>

      <div className='mt-[100px] flex gap-x-2 mx-[425px] items-center'>
          <button className='border-2 py-1 px-4 rounded-md'onClick={()=>navigation(-1)}>Back</button>
          <p className='font-bold text-xl'>Blogs on <span className='underline'>{category}</span></p>
      </div>
          
        

       <div className='mt-[30px] flex flex-col items-center justify-center'>
       <div className='w-11/12 max-w-[670px] flex flex-col gap-y-10  items-center mb-[70px]'>
        {
           
           loading?(<Spinner></Spinner>):(
               
               output?(output.map((post,index)=>(
                  
                   <Main post={post} key={index} ></Main>
                  
                   
               ))):(<div>No data found</div>)
           )
        
          
      }
      </div>
       </div>
       
       {
        totalpage?(<Pagination flag={flag} setflag={setflag} page={page} setpage={setpage} totalpage={totalpage}></Pagination>
       ):(<div>not found</div>)
       }
       
       
    </div>
  )
 
}

export default Category;
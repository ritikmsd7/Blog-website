import React, { useEffect, useState } from 'react'
import Header from '../component/Header'
import Spinner from '../component/Spinner'
import Main from '../component/Main'
import Pagination from '../component/Pagination'

const Home = ({flag,setflag}) => {
   
    const [totalpage,settotalpage]=useState(1);
    const [output,setoutput]=useState();
    const [loading,setloading]=useState(false);
    const [page,setpage]=useState(1);
    const [value,setvalue]=useState("");
    
    const url=()=>{
    if(value===""){
        return `https://codehelp-apis.vercel.app/api/get-blogs?page=${page}`;
    }
    else{
        return `https://codehelp-apis.vercel.app/api/get-blogs?page=${page}&tag=${value}`;
    }
}

     
    

    async function fetchurl(){
        setloading(true);
        try{
        const res=await fetch(url());
        const data=await res.json();
        setoutput(data.posts);
        settotalpage(data.totalPages);
       
        }
        catch(e){
            console.log("error found")
        }
        setloading(false);
    }

    useEffect(()=>{
        fetchurl();
    },[page,value])

  
  return (
    <div className='flex flex-col items-center justify-center' >
        <Header flag={flag} setflag={setflag}  value={value}setvalue={setvalue}></Header>

       <div className='my-[100px]'>
       <div className='w-11/12 max-w-[670px] flex flex-col gap-y-10  items-center'>
        {
           
           loading?(<Spinner></Spinner>):(
               
               output?(output.map((post,index)=>(
                  
                   <Main post={post} key={index} ></Main>
                  
                   
               ))):(<div>No data found</div>)
           )
        
          
      }
      </div>
       </div>
       
       {
        totalpage?(<Pagination flag={flag} setflag={setflag} page={page} setpage={setpage} totalpage={totalpage}></Pagination>
       ):(<div>not found</div>)
       }
       
       
    </div>
  )
}

export default Home
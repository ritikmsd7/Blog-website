import React, { useEffect, useState } from 'react'
import { MdDarkMode } from "react-icons/md";
import { MdOutlineDarkMode } from "react-icons/md";
import { MdOutlineSearch } from "react-icons/md";
import { useLocation } from 'react-router-dom';
const Header = ({flag,setflag,value,setvalue}) => {

  const [button,setbutton]=useState(false);
  const location=useLocation();
  function clickhandler(){
    setflag(!flag);
  }

  function changehandler(event){
   
     setvalue(event.target.value)
  }
  
  const [urlvalue,seturlvalue]=useState("");
  const [urlflag,seturlflag]=useState();
  useEffect(()=>{
   seturlvalue(location.pathname.split("/").at(-1));
  },[location.pathname])

   
  const k=()=>{
    if(urlvalue===""){
      return true;
    }
    else{
      return false;
    }
  }
  
  useEffect(()=>{
    seturlflag(k());
  },)

   console.log(urlflag)
  return (

    <div className='py-4'>
      {
        flag?( <div className=' w-full  border-b-2 py-3 shadow-md  fixed bg-black inset-x-0 top-0 '>
       <h1 className='font-sans font-bold text-3xl uppercase text-center'>Blogs</h1> 

       <div className='ml-[1200px] w-[300px]  flex justify-between cursor-pointer'>
       
       {
        flag?(<div><MdDarkMode onClick={clickhandler}/></div>):(<div><MdOutlineDarkMode onClick={clickhandler}/></div>)
       }

       {
        urlflag?( button?(<div className='flex justify-evenly w-5/6'>
          <input type='text' onChange={changehandler} className='border-2 border-white text-black' value={value}></input>
          <MdOutlineSearch onClick={()=>setbutton(false)}/>
        </div>):(<div><MdOutlineSearch onClick={()=>setbutton(true)}/></div>)):(<div></div>)
       
      
       }
       </div>
       
    </div>):( <div className=' w-full  border-b-2 py-3 shadow-md  fixed bg-white inset-x-0 top-0 '>
       <h1 className='font-sans font-bold text-3xl uppercase text-center'>Blogs</h1> 

       <div className='ml-[1200px] w-[300px]  flex justify-between cursor-pointer'>
       
       {
        flag?(<div><MdDarkMode onClick={clickhandler}/></div>):(<div><MdOutlineDarkMode onClick={clickhandler}/></div>)
       }

       {
        urlflag?(button?(<div className='flex justify-evenly w-5/6'>
          <input type='text' onChange={changehandler} className='border-2 border-black ' value={value}></input>
          <MdOutlineSearch onClick={()=>setbutton(false)}/>
        </div>):(<div><MdOutlineSearch onClick={()=>setbutton(true)}/></div>)):(<div></div>)
        
       }
       </div>
       
    </div>)
      }
    </div>
   
  )
}

export default Header;


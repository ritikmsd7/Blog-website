import React from 'react'

const Pagination = ({page,setpage,totalpage,flag,setflag}) => {
  
return (
  
 <div className='w-full'>
  {
    flag?( <div className=' w-full py-2 border-t-2 shadow-md  fixed bg-black  bottom-0 flex justify-evenly items-center'>

    
{
     1<page && page<totalpage?(<div>
     <button className='border-2 px-4 py-1 rounded-md mx-2 ' onClick={()=>setpage(page-1)}>Previous</button>
     <button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page+1)}>Next</button>
     </div>):(page<totalpage?(<div ><button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page+1)}>Next</button></div>):(<div><button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page-1)}>Previous</button></div>))
  }

  

  <p className='font-bold'>Page {page} of {totalpage}</p>
</div>):( <div className=' w-full py-2 border-t-2 shadow-md  fixed bg-white  bottom-0 flex justify-evenly items-center'>

    
{
     1<page && page<totalpage?(<div>
     <button className='border-2 px-4 py-1 rounded-md mx-2 ' onClick={()=>setpage(page-1)}>Previous</button>
     <button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page+1)}>Next</button>
     </div>):(page<totalpage?(<div ><button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page+1)}>Next</button></div>):(<div><button className='border-2 px-4 py-1 rounded-md mx-2' onClick={()=>setpage(page-1)}>Previous</button></div>))
  }

  

  <p className='font-bold'>Page {page} of {totalpage}</p>
</div>)
  }
 </div>
)
}

export default Pagination;



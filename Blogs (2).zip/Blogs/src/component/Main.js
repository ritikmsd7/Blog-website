import React from 'react'
import { Link } from 'react-router-dom'

const Main = ({post}) => {
  return (
    <div className=''>

        <div className='font-bold text-lg hover:underline'>
        <Link to={`/blog/${post.id}`}>
        {post.title}
        </Link>
        </div>
        <div className='my-1 text-sm'>
        By{" "} 
        <span className='italic'>{post.author} </span>
        On {" "}
         <Link to={`/categories/${post.category.replaceAll(" ","-")}`}>
         <span className=' font-bold underline'>{post.category}</span>
        </Link>
       
        </div>

        <div className='my-1 text-sm'>Posted On {post.date}</div>

        <p className='mt-4 mb-2'>{post.content}</p>
        <div className='flex gap-x-2'>
        {
            post.tags.map((tag,index)=>(
                <div key={index} >
                    <span className=' text-xs font-semibold underline text-blue-700 cursor-pointer'>
                    <Link to={`/tags/${tag.replaceAll(" ","-")}`}>
                    {`#${tag}`}
                    </Link>
                   
                    </span>
                </div>
            ))
        }
        </div>
        
       

    </div>
  )
}

export default Main;